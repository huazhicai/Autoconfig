

# 网关初始IP
BASE_IP = '192.168.1.101'

# 修改后的ip和网关
IP = '192.168.11.190'
GATEWAY = '192.168.11.2'
DNS = '8.8.8.8'

# 号码前缀
PREFIX = '188881190'


# 注册配置
# SERVER_URL = 'dcms.synway.cn'
# COMPANY = '声讯网络'
# ACCOUNT = 'sx_sanhuiwg'
# PASSWORD = 'admin@1234'
# TOKEN = 'SHsxwl321'
# DESCRIBE = '东莞代理-11-191'

