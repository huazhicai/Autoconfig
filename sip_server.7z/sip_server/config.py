

BASE_IP = '192.168.1.152'
# BASE_IP = "xiaoshan.synvn.com:1443"
# BASE_IP = '222.222.98.236:18043'
# https://222.222.98.234:18443/config.php?display=routing&extdisplay=4

USERNAME = 'admin'
PASSWORD = 'admin@1234'


TRUNK_NAME = 'GSM-221'
# \nnat=yes
HOST_PORT = 'host=192.168.11.221\nport=5060\ntype=peer'


# 2017112901
PREFIX = '188888221'
DISPLAY = 'dingxin-221-'
SECRET = 'bu123456'


# # 分机路由三汇
# start = 1
# end = 32


# 分机路由鼎鑫通
start = 0
end = 31

